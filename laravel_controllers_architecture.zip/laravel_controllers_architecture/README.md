# Laravel 12 REST API Architecture

Generated structure for:
- Admin Guard
- User Guard
- Sanctum Authentication
- REST Controllers
- Services
- Form Requests
- API Resources
- Policies

Copy folders into your Laravel project root.
