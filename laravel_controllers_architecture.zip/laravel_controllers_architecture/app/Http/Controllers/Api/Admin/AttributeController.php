<?php

// Laravel 12 Controller generated location
