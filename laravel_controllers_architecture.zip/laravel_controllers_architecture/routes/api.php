<?php
// Generated API route file.
// Add Laravel Sanctum protected admin and user route groups here.
